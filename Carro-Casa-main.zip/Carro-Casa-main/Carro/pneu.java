package Carro;

public class pneu {
    private String tamanho;
    
    public pneu(String tamanho) {
        this.tamanho = tamanho;
    }
    
    public String getTamanho() {
        return tamanho;
    }
}

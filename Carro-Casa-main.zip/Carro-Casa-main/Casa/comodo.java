package Casa;

public class comodo {
    private String nome;
    
    public comodo(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
}